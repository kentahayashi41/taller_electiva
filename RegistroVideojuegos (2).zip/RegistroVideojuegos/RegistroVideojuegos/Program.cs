﻿using Microsoft.Data.Sqlite;

class Program
{
    static void Main(string[] args)
    {
        string cadenaConexion = "Data Source=videojuegos.db";

        using var conexion = new SqliteConnection(cadenaConexion);
        conexion.Open();

        Console.WriteLine("CONEXION EXITOSA A SQLITE");

        using (var comando = conexion.CreateCommand())
        {
            comando.CommandText = @"
                CREATE TABLE IF NOT EXISTS Videojuegos (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Nombre TEXT NOT NULL,
                    Genero TEXT NOT NULL,
                    Anio INTEGER NOT NULL
                );";

            comando.ExecuteNonQuery();
        }

        Console.WriteLine("Tabla creada correctamente.");

        using (var comando = conexion.CreateCommand())
        {
            comando.CommandText = @"
                INSERT INTO Videojuegos (Nombre, Genero, Anio)
                VALUES
                ($n1, $g1, $a1),
                ($n2, $g2, $a2),
                ($n3, $g3, $a3);";

            comando.Parameters.AddWithValue("$n1", "Minecraft");
            comando.Parameters.AddWithValue("$g1", "Sandbox");
            comando.Parameters.AddWithValue("$a1", 2011);

            comando.Parameters.AddWithValue("$n2", "God of War");
            comando.Parameters.AddWithValue("$g2", "Accion");
            comando.Parameters.AddWithValue("$a2", 2018);

            comando.Parameters.AddWithValue("$n3", "Zelda");
            comando.Parameters.AddWithValue("$g3", "Aventura");
            comando.Parameters.AddWithValue("$a3", 2017);

            comando.ExecuteNonQuery();
        }

        Console.WriteLine("Tres videojuegos insertados.");

        using (var comando = conexion.CreateCommand())
        {
            comando.CommandText = "SELECT * FROM Videojuegos";

            using var lector = comando.ExecuteReader();

            Console.WriteLine("\nVIDEOJUEGOS REGISTRADOS:");

            while (lector.Read())
            {
                Console.WriteLine("----------------------");
                Console.WriteLine("ID: " + lector["Id"]);
                Console.WriteLine("Nombre: " + lector["Nombre"]);
                Console.WriteLine("Genero: " + lector["Genero"]);
                Console.WriteLine("Año: " + lector["Anio"]);
            }
        }

        Console.WriteLine("\nPROGRAMA FINALIZADO.");
    }
}
