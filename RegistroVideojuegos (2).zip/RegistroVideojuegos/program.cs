
using Microsoft.Data.Sqlite;

class Program
{
    static void Main(string[] args)
    {
        // Cadena de conexion a la base de datos
        string cadenaConexion =
            "Data Source=videojuegos.db";

        // Crear y abrir la conexion
        using var conexion =
            new SqliteConnection(cadenaConexion);

        conexion.Open();

        Console.WriteLine("CONEXION EXITOSA A SQLITE");

        // Crear la tabla
        using (var comando = conexion.CreateCommand())
        {
            comando.CommandText = @"
                CREATE TABLE IF NOT EXISTS Videojuegos (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Nombre TEXT NOT NULL,
                    Genero TEXT NOT NULL,
                    Anio INTEGER NOT NULL
                );";

            comando.ExecuteNonQuery();
        }

        Console.WriteLine("Tabla creada correctamente.");

        // Insertar tres videojuegos
        using (var comando = conexion.CreateCommand())
        {
            comando.CommandText = @"
                INSERT INTO Videojuegos
                (Nombre, Genero, Anio)
                VALUES
                ($nombre1, $genero1, $anio1),
                ($nombre2, $genero2, $anio2),
                ($nombre3, $genero3, $anio3);";

            comando.Parameters.AddWithValue(
                "$nombre1", "Minecraft");
            comando.Parameters.AddWithValue(
                "$genero1", "Sandbox");
            comando.Parameters.AddWithValue(
                "$anio1", 2011);

            comando.Parameters.AddWithValue(
                "$nombre2", "God of War");
            comando.Parameters.AddWithValue(
                "$genero2", "Accion");
            comando.Parameters.AddWithValue(
                "$anio2", 2018);

            comando.Parameters.AddWithValue(
                "$nombre3", "The Legend of Zelda");
            comando.Parameters.AddWithValue(
                "$genero3", "Aventura");
            comando.Parameters.AddWithValue(
                "$anio3", 2017);

            int registros = comando.ExecuteNonQuery();

            Console.WriteLine(
                $"Registros insertados: {registros}");
        }

        // Consultar los videojuegos
        using (var comando = conexion.CreateCommand())
        {
            comando.CommandText =
                "SELECT * FROM Videojuegos;";

            using var lector = comando.ExecuteReader();

            Console.WriteLine("\nLISTA DE VIDEOJUEGOS");
            Console.WriteLine("-----------------------------");

            while (lector.Read())
            {
                Console.WriteLine(
                    $"ID: {lector["Id"]}");

                Console.WriteLine(
                    $"Nombre: {lector["Nombre"]}");

                Console.WriteLine(
                    $"Genero: {lector["Genero"]}");

                Console.WriteLine(
                    $"Año: {lector["Anio"]}");

                Console.WriteLine("-----------------------------");
            }
        }

        Console.WriteLine(
            "\nConsulta finalizada correctamente.");
    }
}
